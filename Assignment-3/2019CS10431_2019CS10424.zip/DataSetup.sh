mkdir -p $2
./setup $1 $2