#include <bits/stdc++.h>
#include <mpi.h>
#include <omp.h>

#define double float

typedef unsigned int uint;
typedef long long ll;

template <typename T>
using V = std::vector<T>;

template <typename T, typename K>
using P = std::pair<T, K>;
